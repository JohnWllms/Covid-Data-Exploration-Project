CREATE TABLE cvacc(
	iso_code text,
	continent text,
	location text,
	date date,
	total_tests bigint,
	new_tests integer,
	total_tests_per_thousand decimal,
	new_tests_per_thousand decimal,
	new_tests_smoothed decimal,
	new_tests_smoothed_per_thousand decimal,
	positive_rate decimal,
	tests_per_case decimal,
	tests_units text,
	total_vaccinations bigint,
	people_vaccinated bigint,
	people_fully_vaccinated bigint,
	total_boosters bigint,
	new_vaccinations integer,
	new_vaccinations_smoothed decimal,
	total_vaccinations_per_hundred decimal,
	people_vaccinated_per_hundred decimal,
	people_fully_vaccinated_per_hundred decimal,
	total_boosters_per_hundred decimal,
	new_vaccinations_smoothed_per_million decimal,
	new_people_vaccinated_smoothed decimal,
	new_people_vaccinated_smoothed_per_hundred decimal,
	stringency_index decimal,
	population_density decimal,
	median_age decimal,
	aged_65_older decimal,
	aged_70_older decimal,
	gpd_per_capita decimal,
	extreme_poverty decimal,
	cardiovasc_death_rate decimal,
	diabetes_prevalence decimal,
	female_smokers decimal,
	male_smokers decimal,
	handwashing_facilities decimal,
	hospital_beds_per_thousand decimal,
	life_expectancy decimal,
	human_development_index decimal,
	excess_mortality_cumulative_absolute decimal,
	excess_mortality_cumulative decimal,
	excess_mortality decimal,
	excess_mortality_cumulative_per_million decimal	
)
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	